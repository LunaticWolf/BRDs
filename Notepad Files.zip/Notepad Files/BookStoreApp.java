//Book.java
import java.util.Scanner;

public class Book {

	private String bookTitle;
	private String bookAuthor;
	private String bookISBN;
	private int bookCopies;
	
	Book()
	{
	this("null","null","null",0);	
	}
	Book(String bookTitle,String bookAuthor, String bookISBN, int bookCopies)
	{
		this.bookTitle=bookTitle;
		this.bookAuthor=bookAuthor;
		this.bookISBN=bookISBN;
		this.bookCopies=bookCopies;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookISBN() {
		return bookISBN;
	}
	public void setBookISBN(String bookISBN) {
		this.bookISBN = bookISBN;
	}
	public int getBookCopies() {
		return bookCopies;
	}
	public void setBookCopies(int bookCopies) {
		this.bookCopies = bookCopies;
	}
	public void display()
	{
		System.out.println("Book title is :"+ bookTitle);
		System.out.println("Book author is :"+ bookAuthor);
		System.out.println("Book ISBN is :"+ bookISBN);
		System.out.println("No. of copies are :"+ bookCopies);	
	}
}





//BookStore.java


//import java.util.Scanner;


public class BookStore {
	int totalBooks;
	String Title,Author,ISBN;
	int Copies;
	
	Book[] books;
	public void initialise()
		{
			Scanner r=new Scanner(System.in);
			System.out.println("enter total no. of books you want to enter");
			totalBooks = r.nextInt();
			books = new Book[totalBooks];
			for(int i=0;i<totalBooks;i++)
			{
				System.out.println("enter title");
				Title = r.next();
				System.out.println("enter author");
				Author = r.next();
				System.out.println("enter isbn");
				ISBN = r.next();
				System.out.println("enter copies");
				Copies = r.nextInt();
				books[i]=new Book(Title,Author,ISBN,Copies);	
			}
			//r.close();
		}
	public void sell(String Title, int Copies)
	{
		for(int i=0;i<totalBooks;i++)
		{
			if((books[i].getBookTitle().equals(Title))&&(books[i].getBookCopies()>=Copies))
			{
				books[i].setBookCopies(books[i].getBookCopies()-Copies);
				break;
				
			}
			else
			{
				System.out.println("Book not found !!");
			}
		}
	}
	
	public void order(String isbn, int Copies)
	{
		for(int i=0;i<1;i++)
		{
			if((books[i].getBookISBN().equals(isbn)))
			{
				books[i].setBookCopies(books[i].getBookCopies()+Copies);
				//totalBooks++;
				display();
				//break;
			}
			else
			{
				i++;
				Scanner r2=new Scanner(System.in);
				System.out.println("enter title \n");
				Title=r2.nextLine();
				System.out.println("enter author \n");
				Author=r2.nextLine();
				System.out.println("enter isbn \n");
				ISBN=r2.nextLine();
				//System.out.println("enter copies \n");
				//Copies=r2.nextInt();
				books[i]=new Book(Title,Author,ISBN,Copies);
				totalBooks++;
				display();
				r2.close();
			}
		}
	}
	public void display()
	{
		//Scanner r=new Scanner(System.in);
		for(int j=0;j<totalBooks;j++)
		{
			System.out.println("Book title is "+ books[j].getBookTitle());
			System.out.println("enter author " + books[j].getBookAuthor());
			System.out.println("enter isbn" + books[j].getBookISBN());
			System.out.println("enter copies" + books[j].getBookCopies());
		}
}
}




//BookStoreApp.java

//import java.util.Scanner;

public class BookStoreApp {
	
	public static void main(String args[])
	{
		BookStore book=new BookStore();
		book.initialise();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter option: 1." + '\n' + "to display all the books" + '\n' + "2.to order the books" +'\n'+ "3. sell the books");
		
		int choice= scan.nextInt();
		//System.out.println(choice);
		switch(choice)
		{
		case 1:
			book.display();
			break;
		case 2:
			book.order("abc", 100);
			break;
		case 3:
			book.sell("Race 3", 50);
			break;
		case 0:
			System.exit(0);
			break;
		default:
			System.out.println(" Go get some life !!");
			
		}
		scan.close();
		
		
		
		
	}

}
