package main_classes;

public class MainClass {

	public static void main(String[] args) {
		Input i=new Input();
		i.input();

	}

}
