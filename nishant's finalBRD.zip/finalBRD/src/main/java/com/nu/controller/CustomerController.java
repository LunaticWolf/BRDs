package com.nu.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nu.model.persistence.CustomerPojo;
import com.nu.model.persistence.UserPojo;
import com.nu.service.ServiceDao;

@Controller
@RequestMapping("/")
public class CustomerController {
	
	@RequestMapping("/")
	public String welcomePage3() {
		return "login";
	}

	@RequestMapping("/login")
	public String welcomePage2() {
		return "login";
	}

	@RequestMapping("/WelcomeCustomer")
	public String welcomePage() {
		return "WelcomeCustomer";
	}

	@RequestMapping("/Admin")
	public String welcomePage4() {
		return "Admin";
	}

	@Autowired
	ServiceDao serviceDao;
	
	// Insert Customer

	@RequestMapping(value = "/InsertCustomer")
	public String showInsertCustomer() {
		return "InsertCustomer";
	}

	@RequestMapping(value = "/InsertCustomer", method = RequestMethod.POST)
	public String insertCustomer(Model model,
			@ModelAttribute CustomerPojo customer,Principal principal) {
		//customer=(CustomerPojo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String name=principal.getName();
		customer.setCreatedBy(name);
		model.addAttribute(customer);
		serviceDao.insertCustomer(customer);
		return "RecordInserted";
	}

	// Delete Customer
	@RequestMapping(value = "/DeleteCustomer")
	public String showDeleteCustomer() {
		return "DeleteCustomer";
	}

	@RequestMapping(value = "/DeleteCustomer", method = RequestMethod.POST)
	public String deleteCustomer(
			@RequestParam("customerCode") String customerCode) {
		serviceDao.deleteCustomer(customerCode);
		return "RecordDeleted";
	}

	// update customer
	@RequestMapping(value = "/UpdateCustomer")
	public String showUpdateCustomer() {
		return "UpdateCustomer";
	}

	@RequestMapping(value = "/UpdateCustomer", method = RequestMethod.POST)
	public String DoUpdateCustomer(@RequestParam("customerCode") String customerCode, Model model) {
		CustomerPojo pojo = serviceDao.getCustomerByCode(customerCode);
		model.addAttribute("customer", pojo);
		return "DoUpdateCustomer";
	}
	
	
	/*@RequestMapping(value = "/UpdateCustomer", method = RequestMethod.POST)
	public ModelAndView DoUpdateCustomer(@RequestParam("customerCode") String customerCode) {
		CustomerPojo pojo = serviceDao.getCustomerByCode(customerCode);	
		System.out.println("################### "+pojo);
		return new ModelAndView("DoUpdateCustomer","customer",pojo);
	}*/
	
	@RequestMapping("/DoUpdateCustomer")
	public String updateCustomer(CustomerPojo customer) {
		serviceDao.updateCustomer(customer);
		return "WelcomeCustomer";
	}

	// view all
	@RequestMapping(value = "ViewAll")
	public String doViewAll(Model model) {
		List<CustomerPojo> list = serviceDao.getAllCustomers();
		System.out.println(list);
		model.addAttribute("customer", list);
		return "ViewAll";
	}

	// single view
	@RequestMapping(value = "OneView")
	public String doOneView() {
		return "OneView";
	}

	@RequestMapping(value = "OneView", method = RequestMethod.POST)
	public String oneView(Model model,
			@RequestParam("customerCode") String customerCode) {
		CustomerPojo pojo = serviceDao.getCustomerByCode(customerCode);
		model.addAttribute("customer", pojo);
		return "ViewCustomer";
	}

	// logout
	@RequestMapping(value = "Logout")
	public String LogOut(HttpServletRequest request) {
		request.getSession().invalidate();
		return "login";
	}
/*----------------------------------------------------------------------*/
	@RequestMapping(value = "/AddUser")
	public String registerNewUser() {
		return "AddUser";
	}

	@RequestMapping(value = "/AddUser", method = RequestMethod.POST)
	public String newUserRegistered(
			@ModelAttribute(value = "user") UserPojo user, Model model) {
		/*pojo.setEnabled("1");*/
		serviceDao.insertUser(user);
		return "AddUser";
	} 
	@RequestMapping(value="/ViewUser")
	public String viewUser(Model model){
		System.out.println("123");
		List<UserPojo> list=serviceDao.ViewAll();
		System.out.println("ttttt");
		System.out.println(list);
		model.addAttribute("user", list);
		System.out.println(list);
		return "ViewUser";
	}
}