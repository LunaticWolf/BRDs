package com.nu.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nu.dao.CustomerDao;
import com.nu.dao.UserDao;
import com.nu.model.persistence.CustomerPojo;
import com.nu.model.persistence.UserPojo;

@Service
public class ServiceDaoImpl implements ServiceDao {

	@Autowired
	CustomerDao dao;
	@Autowired
	UserDao userDao;

	@Transactional
	public CustomerPojo insertCustomer(CustomerPojo customer) {
		return dao.insertCustomer(customer);
	}

	@Transactional
	public void deleteCustomer(String customerCode) {
	dao.deleteCustomer(customerCode); 
	}

	@Transactional
	public CustomerPojo updateCustomer(CustomerPojo customer) {
		return dao.updateCustomer(customer);
	}

	@Transactional
	public CustomerPojo getCustomerByCode(String customerCode) {
		return dao.getCustomerByCode(customerCode);
	}

	@Transactional
	public List<CustomerPojo> getAllCustomers() {
		return dao.getAllCustomers();
	}

	@Transactional
	public boolean insertUser(UserPojo user) {
		userDao.insertUser(user);
		return false;
	}

	@Transactional
	public List<UserPojo> ViewAll() {
		return userDao.ViewAll();
	
	}

}
