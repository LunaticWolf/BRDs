package com.nu.service;

import java.util.List;

import com.nu.model.persistence.CustomerPojo;
import com.nu.model.persistence.UserPojo;

public interface ServiceDao {

	public CustomerPojo insertCustomer(CustomerPojo customer);

	public void deleteCustomer(String customerCode);

	public CustomerPojo updateCustomer(CustomerPojo customer);

	public CustomerPojo getCustomerByCode(String customerCode);

	public List<CustomerPojo> getAllCustomers();

	public boolean insertUser(UserPojo user);

	public List<UserPojo> ViewAll();

}