package com.nu.dao;

import java.util.List;

import com.nu.model.persistence.CustomerPojo;

public interface CustomerDao {

	public CustomerPojo insertCustomer(CustomerPojo customer);

	public void deleteCustomer(String customerCode);

	public CustomerPojo updateCustomer(CustomerPojo customer);

	public CustomerPojo getCustomerByCode(String customerCode);

	public List<CustomerPojo> getAllCustomers();

}