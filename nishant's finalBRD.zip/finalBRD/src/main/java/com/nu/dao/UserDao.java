package com.nu.dao;

import java.util.List;

import com.nu.model.persistence.UserPojo;

public interface UserDao {

	public boolean insertUser(UserPojo user);

	public List<UserPojo> ViewAll();

}
