package com.nu.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nu.model.persistence.CustomerPojo;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private SessionFactory factory;

	public CustomerPojo insertCustomer(CustomerPojo customer) {
		Date date=new Date();
		customer.setRegistrationDate(date);
		factory.getCurrentSession().saveOrUpdate(customer);
		return customer;
	}

	public void deleteCustomer(String customerCode) {

		CustomerPojo pojo = new CustomerPojo();
		pojo.setCustomerCode(customerCode);
		factory.getCurrentSession().delete(pojo);
	}

	public CustomerPojo updateCustomer(CustomerPojo pojo) {
		Date date=new Date();
		pojo.setModifiedDate(date);
		System.out.println(pojo);
		factory.getCurrentSession().update(pojo);
		return pojo;
	}

	@SuppressWarnings("unchecked")
	public CustomerPojo getCustomerByCode(String customerCode) {
		System.out.println("--------------------------------------");
		CustomerPojo cust =null;
		  Query query = factory.getCurrentSession().createQuery("from CustomerPojo u where u.customerCode=:customerCode");
			query.setParameter("customerCode", customerCode);
			List<CustomerPojo> customer = query.list();
			if (!customer.isEmpty()) {
				cust = customer.get(0);
			}
	  return cust;
	  }
		
		/*CustomerPojo pojo = (CustomerPojo) factory.getCurrentSession().get(
				CustomerPojo.class, customerCode);
		return pojo;*/
	

	@SuppressWarnings("unchecked")
	public List<CustomerPojo> getAllCustomers() {
		return factory.getCurrentSession().createCriteria(CustomerPojo.class).list();
	}

}
