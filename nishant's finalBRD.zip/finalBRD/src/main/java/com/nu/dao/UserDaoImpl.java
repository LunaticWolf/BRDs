package com.nu.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nu.model.persistence.UserPojo;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	SessionFactory factory;

	@Override
	public boolean insertUser(UserPojo user) {
		factory.getCurrentSession().saveOrUpdate(user);
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserPojo> ViewAll() {
		return factory.getCurrentSession().createCriteria(UserPojo.class)
				.list();
	}

}
