package com.nu.model.persistence;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Nishant180")
public class UserPojo {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int userId;
	@Column(name = "UserName")
	private String userName;
	@Column(name = "Password")
	private String userPassword;
	@Column(name = "Enabled")
	private String enabled;
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private RolePojo role;

	public UserPojo() {
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public UserPojo(int userId, String userName, String userPassword,
			String enabled) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.enabled = enabled;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
}
