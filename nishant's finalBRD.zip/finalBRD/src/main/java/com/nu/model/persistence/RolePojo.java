package com.nu.model.persistence;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="Nishant267")

public class RolePojo {

		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE)
		private int roleId;
		@NotNull
		private String role;
		@Temporal(TemporalType.DATE)
		private Date registrationDate;
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public Date getRegistrationDate() {
			return registrationDate;
		}
		public void setRegistrationDate(Date registrationDate) {
			this.registrationDate = registrationDate;
		}
		public RolePojo(int roleId, String role, Date registrationDate) {
			super();
			this.roleId = roleId;
			this.role = role;
			this.registrationDate = registrationDate;
		}
		@Override
		public String toString() {
			return "RolePojo [id=" + roleId + ", role=" + role
					+ ", registrationDate=" + registrationDate + "]";
		}
		public RolePojo() {
			super();
		}
}
