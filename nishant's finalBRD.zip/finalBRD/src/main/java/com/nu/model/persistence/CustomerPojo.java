package com.nu.model.persistence;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Nishantnsbt")
public class CustomerPojo {

	@Id
	private String customerCode;
	private String customerName;
	private String customerAddress;
	private int customerPinCode;
	private String customerEmail;
	private String contactNumber;
	//@Temporal(TemporalType.DATE)
	private Date registrationDate;
	private String createdBy;
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;

	public CustomerPojo() {
		super();
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getCustomerPinCode() {
		return customerPinCode;
	}

	public void setCustomerPinCode(int customerPinCode) {
		this.customerPinCode = customerPinCode;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdby) {
		this.createdBy = createdby;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public CustomerPojo(String customerCode, String customerName,
			String customerAddress, int customerPinCode, String customerEmail,
			String contactNumber, Date registrationDate, String createdby,
			Date modifiedDate) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPinCode = customerPinCode;
		this.customerEmail = customerEmail;
		this.contactNumber = contactNumber;
		this.registrationDate =new Date();
		this.createdBy = createdby;
		this.modifiedDate = modifiedDate;
	}

	@Override
	public String toString() {
		return "CustomerPojo [CustomerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress=" + customerAddress
				+ ", customerPinCode=" + customerPinCode + ", customerEmail="
				+ customerEmail + ", contactNumber=" + contactNumber
				+ ", registrationDate=" + registrationDate + ", createdby="
				+ createdBy + ", modifiedDate=" + modifiedDate + "]";
	}
}
